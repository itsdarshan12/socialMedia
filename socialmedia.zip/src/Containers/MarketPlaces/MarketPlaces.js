import React from 'react';
import classes from './MarketPlaces.module.css';

const MarketPlaces = () => {
    return (
        <div>
            <p>MarketPlaces List</p>
        </div>
    );
};

export default MarketPlaces;