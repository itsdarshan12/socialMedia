import React from 'react';
import classes from './Photos.module.css';

const Photos = () => {
    return (
        <div>
            <p>Photos List</p>
        </div>
    );
};

export default Photos;