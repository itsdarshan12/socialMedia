import React from 'react';
import classes from './Files.module.css';

const Files = () => {
    return (
        <div>
            <p>Files List</p>
        </div>
    );
};

export default Files;