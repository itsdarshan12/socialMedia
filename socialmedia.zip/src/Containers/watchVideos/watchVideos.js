import React from 'react';
import classes from './watchVideos.module.css';

const Videos = () => {
    return (
        <div>
            <p>Videos List</p>
        </div>
    );
};

export default Videos;