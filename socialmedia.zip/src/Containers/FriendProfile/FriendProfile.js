import React from 'react';
import classes from './FriendProfile.module.css';

const FriendProfile = () => {
    return (
        <div>
           <p>Friend Profile</p>
        </div>
    );
};

export default FriendProfile;