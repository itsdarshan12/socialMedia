import React from 'react';
import classes from './Events.module.css';

const Events = () => {
    return (
        <div>
            <p>Events List</p>
        </div>
    );
};

export default Events;