import DefaultUser from '../Media/DefaultsImages/User.png';
import Post from '../Media/DefaultsImages/Post.jpg';
import UserFemale from '../Media/DefaultsImages/UserFemale.png';
import DefaultPicture from '../Media/DefaultsImages/DefaultPicture.png';

export const User = DefaultUser;
export const defaultPost = Post;
export const UserGirl = UserFemale;
export const DefaultPic = DefaultPicture;