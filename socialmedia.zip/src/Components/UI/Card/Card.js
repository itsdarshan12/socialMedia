import React from 'react';
import { Col } from 'react-bootstrap';
import classes from './Card.module.css';

const Card = (props) => {
    return (
        <Col sm={12}>
            <div className={classes.Card}>

            </div>
        </Col>
    );
};

export default Card;